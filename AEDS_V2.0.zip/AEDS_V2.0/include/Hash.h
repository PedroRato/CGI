#ifndef HASH_H
#define HASH_H

#include <iostream>
#include <string>
#include <list>

#include "Tree.h"

struct N_word{
    std::string word;
    std::list<long> pos;
};
struct Archive{
    std::string archive;
    long size;
    std::vector <long> pos;
};

class Hash{
public:

    void insert(std::string,std::string,long);
    void print(int);
    std::vector<Archive> search(std::string);
    std::vector<Archive> verify();
    std::vector<N_word> analyze(std::vector<N_word>,long,std::vector<N_word>);

private:
    std::list<word> s_words;
    Tree hash[47]; ///Size of the the biggest word in portuguese

    int hash_KEY(std::string);

};

void Test();

#endif // HASH_H
