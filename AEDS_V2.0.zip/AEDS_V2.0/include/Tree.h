#ifndef TREE_H
#define TREE_H

#include<string>
#include<vector>
#include<list>
#include<map>

long indexArch(std::string);
std::string Data_Text(long);
long numText();

struct word{ ///A class for the output of an item in the tree
    std::string word;
    std::vector<std::list<long> > pos;
};

class Ins{ ///A class to insert a new item in the tree
public:
    Ins(std::string,std::string,long);
    std::string archive();
    std::string key();
    long position();
private:
    std::string Archive;
    std::string Key;
    long pos;
};

struct Node{ ///Node of the tree
    std::string key;
    Node* left;
    Node* right;
    long height;
    std::vector<std::list<long> > find;
};

class Tree{ ///The Big TREE
public:
    Tree();
    void ins(Ins);
    void print();
    void sch(std::string,word&);
private:
    //Root
    Node* root;
    //Balance
    long height(Node*);
    long getBalance(Node*);
    //Insert
    Node* insert(Node*,std::string,long,std::string);
    //Rotate
    Node* newNode(std::string,long,std::string);
    Node* rightRotate(Node*);
    Node* leftRotate(Node*);
    //Search
    Node* search(Node*,std::string);
    //Print
    void postorder(Node*,long indent);
};

#endif // TREE_H
