var searchData=
[
  ['web',['web',['../classweb.html',1,'web'],['../classweb.html#a4b8e4e0bf619f0baa6d918b0c49642b0',1,'web::web()']]],
  ['word',['word',['../structword.html',1,'word'],['../structword.html#af262cc406ed07701df60cba82ae4be91',1,'word::word()']]]
];
