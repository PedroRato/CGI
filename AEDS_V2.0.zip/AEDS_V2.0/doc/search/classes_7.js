var searchData=
[
  ['web',['web',['../classweb.html',1,'']]],
  ['word',['word',['../structword.html',1,'']]]
];
