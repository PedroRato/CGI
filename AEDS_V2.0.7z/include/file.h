#ifndef FILE_H
#define FILE_H

#include <iostream>
#include <fstream>
#include <vector>
#include <ctype.h>

class file{
public:
    file();
    ~file();
    void read(std::string,std::string&);
    void readFromRobots(std::vector<std::string>&);
};

#endif // FILE_H
