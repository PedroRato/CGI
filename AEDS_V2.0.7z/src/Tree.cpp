#include "Tree.h"

#include<iostream>
#include<string>
#include<list>
#include<vector>

std::map<std::string,long>Data;
std::map<long,std::string>data_Text;
long numberText=1;

long indexArch(std::string text){
    if(!Data[text]){
        data_Text[numberText-1]=text;
        Data[text]=numberText++;
    }
    return (Data[text]-1);
}

std::string Data_Text(long num_text){
    return (data_Text[num_text]);
}

long numText(){
    return numberText;
}

// Maximo de duas long
long max(long a, long b){
  return (a > b)? a : b;
}

Ins::Ins(std::string archive,std::string key,long pos){
    this->Key=key;
    this->pos=pos;
    this->Archive=archive;
}

std::string Ins::archive(){return Archive;}
std::string Ins::key(){return Key;}
long Ins::position(){return pos;}

// Acha a altura da arvore
long Tree::height(Node* N){
  if (N == NULL)
    return 0;
  return N->height;
}

// Retorna a Altura balanceada do no N
long Tree::getBalance(Node* N){
  if (N == NULL)
    return 0;
  return height(N->left) - height(N->right);
}

Tree::Tree(){
    this->root=NULL;
}

// Aloca um novo no
Node* Tree::newNode(std::string key, long pos,std::string archive){
  Node* node = new Node;
  node->key  = key;
  node->left  = NULL;
  node->right = NULL;
  node->height = 1; // O novo no � adicionado como folha
  for(long i=0;node->find.size()<=indexArch(archive);i++){
    node->find.push_back(std::list<long>());
  }
  node->find[indexArch(archive)].push_back(pos);
  return(node);
}

// Roda a subtree para a direita
Node* Tree::rightRotate(Node* y){
  Node* x = y->left;
  Node* T2 = x->right;

  // Rota��o
  x->right = y;
  y->left = T2;

  // Atualiza a autura
  y->height = max(height(y->left), height(y->right))+1;
  x->height = max(height(x->left), height(x->right))+1;

  // Retorna a nova raiz
  return x;
}

// Roda a subtree para a esquerda
Node* Tree::leftRotate(Node* x){
  Node* y = x->right;
  Node* T2 = y->left;

  // Rota��o
  y->left = x;
  x->right = T2;

  // Atualiza a altura
  x->height = max(height(x->left), height(x->right))+1;
  y->height = max(height(y->left), height(y->right))+1;

  // Retorna a nova raiz
  return y;
}
void Tree::ins(Ins key){
    this->root=insert(root, key.key(), key.position(), key.archive());
}
// Fun��o recursiva para adicionar um novo No
Node* Tree::insert(Node* node,std::string key,long pos,std::string archive){
  /* 1. Insere normalmente */
  if (node == NULL)
    return(newNode(key,pos,archive));
  if (key < node->key)
    node->left = insert(node->left, key, pos, archive);
  else if (key > node->key)
    node->right = insert(node->right, key, pos, archive);
  else{
    for(long i=0;node->find.size()<=indexArch(archive);i++)
        node->find.push_back(std::list<long>());
    node->find[indexArch(archive)].push_back(pos);
    return node;
  }
  /* 2. Atualiza a autura do No antecessor */
  node->height = 1 + max(height(node->left),height(node->right));

  /* 3. Pega o fator de balanceamento do antecessor
  para chegar se quando que o no se torna desbalanceado*/
  long balance = getBalance(node);

  // Quando ele est� desbalanceado

  // Esquerda esquerda
  if (balance > 1 && key < node->left->key)
    return rightRotate(node);

  // Direita direita
  if (balance < -1 && key > node->right->key)
    return leftRotate(node);

  // Esquerda direita
  if (balance > 1 && key > node->left->key){
    node->left = leftRotate(node->left);
    return rightRotate(node);
  }

  // Direitae squerda
  if (balance < -1 && key < node->right->key){
    node->right = rightRotate(node->right);
    return leftRotate(node);
  }

  /* retorna o no que n foi mudado */
  return(node);
}

void Tree::sch(std::string key, word& ret_Word){
    Node* Answer(search(root, key));
    if(Answer==NULL){
        ret_Word.word.clear();
        ret_Word.pos.clear();
    }else{
        ret_Word.word=Answer->key;
        ret_Word.pos=Answer->find;
    }
}

Node* Tree::search(Node* node,std::string key){
  if(node == NULL)
    return(NULL);
  else if (key < node->key)
    return search(node->left, key);
  else if (key > node->key)
    return search(node->right, key);
  else
    return(node);
}


// Print postorder
// Print a altura height
void Tree::print(){postorder(root,0);}

void Tree::postorder(Node* root, long indent){
    if(root != NULL) {
        long i=indent;
        postorder(root->left, indent+4);
        while (i--) std::cout << ' ';
        std::cout<<root->key<<std::endl;
        postorder(root->right, indent+4);
    }
}
