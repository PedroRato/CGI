#include "web.h"

/** \brief
 * O m�todo cria o in�cio da p�gina, que deve ser precedido do start_container
 */
web::web(){
    std::cout << "Content-type: text/html\n\n";
    std::cout << "<!DOCTYPE html>";
    std::cout << "<html>";
    std::cout << "<head>";
        std::cout << "<meta charset=\"utf-8\">";
        std::cout << "<meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">";
        std::cout << "<link rel=\"stylesheet\" href=\"https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css\">";
        std::cout << "<script src=\"https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js\"></script>";
        std::cout << "<script src=\"https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js\"></script>";
        std::cout << "<style type=\"text/css\">.navbar-default .navbar-nav>li>a {color: #337cbb;}.navbar-default .navbar-nav>li>a:hover {color: #144977;}.navbar-default .navbar-toggle:hover,.navbar-default .navbar-toggle:focus,.navbar-default .navbar-toggle,.navbar,.navbar-default .navbar-collapse,.navbar-default .navbar-form {background-color: #fff;border: 0px;} </style>";
    std::cout << "</head>";
    std::cout << "<body>";
        std::cout << "<div class=\"navbar navbar-default\">";
            std::cout << "<div class=\"container-fluid\">";
                std::cout << "<div class=\"navbar-header\">";
                    std::cout << "<button type=\"button\" class=\"navbar-toggle\" data-toggle=\"collapse\" data-target=\"#navbar-ex-collapse\">";
                        std::cout << "<span class=\"sr-only\">Toggle navigation</span>";
                        std::cout << "<span class=\"icon-bar\"></span>";
                        std::cout << "<span class=\"icon-bar\"></span>";
                        std::cout << "<span class=\"icon-bar\"></span>";
                    std::cout << "</button>";
                std::cout << "</div>";
                std::cout << "<div class=\"collapse navbar-collapse\" id=\"navbar-ex-collapse\">";
                    std::cout << "<ul class=\"nav navbar-nav navbar-right\">";
                        std::cout << "<li class="">";
                                std::cout << "<a href=\"Download Page\">";
                                    std::cout << "<span class=\"glyphicon glyphicon-download-alt\"></span>";
                                std::cout << "</a>";
                        std::cout << "</li>";
                        std::cout << "<li class="">";
                                std::cout << "<a href=\"index.html\">";
                                    std::cout << "<span class=\"glyphicon glyphicon-home\"></span>";
                                std::cout << "</a>";
                        std::cout << "</li>";
                    std::cout << "</ul>";
                std::cout << "</div>";
        std::cout << "</div>";
}

web::~web(){
}

/** \brief
 * O m�todo cria a se��o onde vai ficar o texto
 * \return void
 */
void web::start_container(){
        std::cout << "<div class=\"section\">";
            std::cout << "<div class=\"container\">";
                std::cout << "<div class=\"row\">";
                    std::cout << "<div class=\"col-md-12 text-center\">";
                        std::cout << "<div class=\"page-header text-center\">";
}

/** \brief
 * O m�todo d� enf�se no termo de busca. [Pode ser usado mais de uma vez]
 * \param wordTitle (std::string). Termo de busca.
 * \return void
 */
void web::title(std::string wordTitle){
                            std::cout << "<h1>" << wordTitle << "</h1><br><br>";
}

/** \brief
 * O m�todo coloca cada trecho como um �nico par�grafo. [Pode ser usado mais de uma vez]
 * \param wordTxt (std::string). Frase/trecho.
 * \return void
 */
void web::txt(std::string wordTxt){
                            std::cout << "<p>" << wordTxt;
}

/** \brief
 * O m�todo faz o indexamento do texto de onde foi tirado o m�todo txt.
 * \param wordLink (std::string)
 * \return void
 */
void web::link(std::string wordLink){
                            std::cout << "<br><a href=\"" << wordLink << "\">" << wordLink << "</a>";
}

/** \brief
 * O m�todo termina o html
 * \return void
 */
void web::end_container(){
                        std::cout << "</div>";
                    std::cout << "</div>";
                std::cout << "</div>";
            std::cout << "</div>";
        std::cout << "</div>";
    std::cout << "</body>";
    std::cout << "</html>";
}
