#include "file.h"

file::file(){
}
file::~file(){
}

/** \brief
 * O m�todo l� o arquivo e salva em uma string original(Param2) e tamb�m em uma string secund�ria limpa de acentos e char espciais.
 * \param path (std::string). Caminho de leitura com extens�o .txt
 * \param cleanString (std::string&). String para salvar o arquivo lido no texto.
 * \return void
 */
void file::read(std::string path, std::string &cleanString){
    std::ifstream input (path.c_str());
    if(!input.is_open())
        std::cerr << "Erro ao abrir \"gestor de arquivos\"";
    else{
        char d;
        auto cleanD = [](char c) -> char {
            if((c=='�' || c=='�')||(c=='�' || c=='�')||(c=='�' || c=='�')||(c=='�' || c=='�'))
                return 'a';
            else if((c=='�' || c=='�')||(c=='�' || c=='�')||(c=='�' || c=='�'))
                return 'e';
            else if((c=='�' || c=='�')||(c=='�')||(c=='�')||(c=='�' || c=='�'))
                return 'i';
            else if((c=='�' || c=='�')||(c=='�' || c=='�')||(c=='�' || c=='�')||(c=='�' || c=='�'))
                return 'o';
            else if((c=='�' || c=='�')||(c=='�')||(c=='�')||(c=='�' || c=='�'))
                return 'u';
            else if(c=='�' || c=='�')
                return 'c';
        };
        while(input.get(d)){
            if(islower(d) || isdigit(d))
                cleanString.push_back(d);
            else{
                d = tolower(cleanD(d));
                if(islower(d) or isspace(d))
                    cleanString.push_back(d);
            }
        }
        input.close();
    }
}

/** \brief
 * Devolve um vector de string com o nome dos arquivos que podem ser lidos
 * \param robots (std::vector<std::string>&).
 * \return void
 */
void file::readFromRobots(std::vector<std::string>& robots){
    std::ifstream input ("robots.txt");
    if(!input.is_open())
        std::cerr << "Erro ao abrir \"gestor de arquivos\"";
    else{
        char d[256];
        std::string aux;
        while(input.getline(d, 256))
            robots.push_back(d);
        input.close();
    }
}
