var searchData=
[
  ['sortarch',['sortArch',['../structsort_arch.html',1,'']]],
  ['sortvec',['sortVec',['../structsort_vec.html',1,'']]]
];
