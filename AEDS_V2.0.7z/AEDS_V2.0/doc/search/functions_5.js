var searchData=
[
  ['read',['read',['../classfile.html#a1430baf5b8d93356bec8048102853beb',1,'file']]],
  ['readfromrobots',['readFromRobots',['../classfile.html#a93fc65f67b4ce1b0015cb9b5d4d5fd91',1,'file']]]
];
