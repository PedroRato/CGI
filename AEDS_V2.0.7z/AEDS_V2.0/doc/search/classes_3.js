var searchData=
[
  ['ins',['Ins',['../class_ins.html',1,'']]]
];
