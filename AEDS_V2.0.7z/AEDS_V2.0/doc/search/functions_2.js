var searchData=
[
  ['ins',['Ins',['../class_ins.html#a251cc047caf9771acbf11558dfd01972',1,'Ins']]],
  ['insert',['insert',['../class_hash.html#a216d51a7624460977dcb131469312670',1,'Hash']]]
];
