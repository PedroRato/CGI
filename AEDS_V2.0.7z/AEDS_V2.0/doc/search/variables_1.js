var searchData=
[
  ['word',['word',['../structword.html#af262cc406ed07701df60cba82ae4be91',1,'word']]]
];
