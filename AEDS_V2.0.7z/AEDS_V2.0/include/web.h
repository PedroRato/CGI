#ifndef WEB_H
#define WEB_H

#include <iostream>

class web{

    public:
        web();
        virtual ~web();
        void title(std::string);
        void txt(std::string);
        void link(std::string);
        void start_container();
        void end_container();
};

#endif // WEB_H
