#include <iostream>
#include <cstdlib>
#include <string.h>
#include <cstdio>
#include <vector>
#include <sstream>

#include "Hash.h"
#include "file.h"
#include "web.h"

int main(int argc, char **argv, char **envp){
    ///< Caso fique lento, colocar page de loading para dar efeito
    std::vector<std::string> files_in_folder;
    file rwFile;
    rwFile.readFromRobots(files_in_folder);                 ///< L� o arquivo robots que cont�m o nome dos arquivos.

    std::vector<std::vector<std::string>> readFile;{        ///< L� os arquivos e salva em strings
        std::string aux;
        std::stringstream ss;
        std::vector<std::string> ax;
        for(size_t i=0; i<files_in_folder.size(); i++, ss.clear(), aux.clear(),ax.clear()){
            rwFile.read(files_in_folder[i], aux);           ///< Faz a leitura do arquivo cujo nome est� na posi��o 0 do robots
            ss << aux;
            while(ss >> aux)ax.push_back(aux);
            readFile.push_back(ax);
        }
    }

    Hash hash;{                                             ///< Cria o hash e realiza a inser��o de cada palavra.
    for(int i=0; i<files_in_folder.size(); i++){
        for(int d=0; d<readFile[i].size(); d++)
            hash.insert(files_in_folder[i], readFile[i][d], d);
        }
    }

    ///<            CGI         //////////
    char *qPtr;
    if(qPtr = getenv("QUERY_STRING")){
        char buffer[256];
        char *token;
        char _field[80];

        strncpy(buffer,qPtr,255);
        token = strtok(buffer, "&");
        sscanf(token, "pesquisa=%s",_field);

        auto utfCode_to_char = [](std::string var) -> char{
            if(var == "%C3%80" || var == "%C3%81" || var == "%C3%83" || var == "%C3%A0" || var == "%C3%A1" || var == "%C3%A3" || var == "%C3%82" || var == "%C3%A2")
                return 'a';
            else if(var == "%C3%88" || var == "%C3%89" || var == "%C3%8A" ||  var == "%C3%A8" || var == "%C3%A9" || var == "%C3%AA")
                return 'e';
            else if(var == "%C3%8C" || var == "%C3%8D" || var == "%C3%8E" ||  var == "%C3%AC" || var == "%C3%AD" || var == "%C3%AE")
                return 'i';
            else if(var == "%C3%92" || var == "%C3%93" || var == "%C3%94" ||  var == "%C3%95" || var == "%C3%B2" || var == "%C3%B3" || var == "%C3%B4" || var == "%C3%B5")
                return 'o';
            else if(var == "%C3%99" || var == "%C3%9A" || var == "%C3%9B" || var == "%C3%B9" || var == "%C3%BA" || var == "%C3%BB")
                return 'u';
            else if(var == "%C3%87" || var == "%C3%A7")
                return 'c';
        };

        std::string field;                              ///< \var Palavra de pesquisa
        std::string code;
        for(size_t i=0, j = 0; i<strlen(_field); i++, code.clear()){
            if(!isalpha(_field[i])){
                if(ispunct(_field[i])){
                    if(_field[i] == '+')
                        field.push_back(' ');
                    else{
                        for(j=i; j<(i+6); j++)
                            code.push_back(_field[j]);
                        field.push_back(utfCode_to_char(code));
                        i = j-1;
                    }
                }
            }
            else    field.push_back(tolower(_field[i]));
        }

        web page;
        page.start_container();
        page.title(field);

        std::vector<Archive> found = hash.search(field);
        if(found.empty())   page.txt("Palavra nao encontrada");
        else{
           for(long arch=0; arch < found.size(); arch++){
                if(!found[arch].pos.empty()){
                    page.txt("");

                    int aux_index_arquivo=indexArch(found[arch].archive);
                    for(long j=found[arch].pos.front(); j <= found[arch].pos.back(); j++, std::cout << " ")
                        std::cout << readFile[aux_index_arquivo][j];

                    page.link(found[arch].archive);
                }
                std::cout << "<br><br>";
            }
        }
        page.end_container();
        return 0;
    }
    else{
        std::cerr << "Content-type: text/html\n\n<html><head></head><body><h1 align=\"center\">Nao foi possivel recuperar string de pesquisa</h1></body></html>";
        return 1;
    }
    ///<            !CGI         //////////
}
