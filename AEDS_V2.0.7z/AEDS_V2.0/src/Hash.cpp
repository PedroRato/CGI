#include "Hash.h"
#include "Tree.h"

#include <iostream>
#include <string>
#include <sstream>
#include <algorithm>

struct sortVec {
    bool operator()(const N_word &f, const N_word &l) {
        return f.pos.front() < l.pos.front();
    }
};

struct sortArch {
    bool operator()(const Archive &f, const Archive &l) {
        return f.size > l.size;
    }
};

/** \brief
 * Valor de um vetor de N_Words para facilitar a leitura das posi�oe dado um arquivo
 * \param key (std::list<word>). Lista de palavras com posi�oes em TODOS os arquivos
 * \param indexA (int). Index do arquivo desejado.
 * \return (std::vector<N_word>). Lista de palavra SOMENTE com as posi�oes no aquivo desejado.
 */
std::vector<N_word> transform (std::list<word> key,int indexA){
    N_word ret;
    std::vector<N_word> Vec_ret;
    word aux;
    aux.pos.clear();
    aux.word.clear();

    while(!key.empty()){
        ret.word = key.front().word;
        for(long i=0;key.front().pos.size()<=indexA;i++)
            key.front().pos.push_back(std::list<long>());
        ret.pos = key.front().pos[indexA];
        Vec_ret.push_back(ret);
        key.pop_front();
    }
    return Vec_ret;
}

/** \brief
 * O m�todo retorna o valor de um vetor de N_Words sendo que o primeiro
 * valor de cada vetor pos corresponde � melhor posi��o;
 * \param current (std::vector<N_word>). Lista de palavras com posi�oes atuais
 * \param distance (long). Distancia das palavras
 * \param current (std::vector<N_word>). Lista de palavras com posi�oes atuais
 * \param best (std::vector<N_word>). Melhor organiza�ao das palavras relativo a sua posi�ao at� o momento.
 * \return (std::vector<N_word>). Melhor organiza�ao das palavras.
 */
std::vector<N_word> Hash::analyze (std::vector<N_word> current,long distance,std::vector<N_word> best){
    long new_distance = (current.back().pos.front() - current.front().pos.front());
    if(new_distance==current.size())
        return current;
    if(new_distance<distance){
        distance=new_distance;
        best=current;
    }
    current.front().pos.pop_front();
    if(current.front().pos.empty())
        return best;
    sort(current.begin(),current.end(),sortVec());

    return analyze(current,distance,best);
}

/** \brief
 * O valor retornado varia de 0 � 46
 * \param key (std::string). Nome do arquivo.
 * \return (int). Index para se alocar aquela palavra
 */
int Hash::hash_KEY(std::string key){
    return key.size()%47;
}

/** \brief
 * A inser�ao realmente ocorre na fun�ao insert da biblioteca Tree
 * \param archive (std::string). Nome do arquivo
 * \param key (std::string). O que se deseja inserir
 * \param pos (long). Posi�ao no texto do que vai ser inserido
 * \return (void)
 */
 void Hash::insert(std::string archive, std::string key,long pos){
    if(key[key.size()-1]=='!'||key[key.size()-1]=='@'||key[key.size()-1]=='#'||
       key[key.size()-1]=='$'||key[key.size()-1]=='%'||key[key.size()-1]=='^'||
       key[key.size()-1]=='&'||key[key.size()-1]=='*'||key[key.size()-1]=='('||
       key[key.size()-1]==')'||key[key.size()-1]=='�'||key[key.size()-1]=='_'||
       key[key.size()-1]=='+'||key[key.size()-1]=='='||key[key.size()-1]=='{'||
       key[key.size()-1]=='}'||key[key.size()-1]=='['||key[key.size()-1]==']'||
       key[key.size()-1]=='|'||key[key.size()-1]=='/'||key[key.size()-1]==':'||
       key[key.size()-1]==';'||key[key.size()-1]=='�'||key[key.size()-1]=='�'||
       key[key.size()-1]==','||key[key.size()-1]=='.'||key[key.size()-1]=='?'||
       key[key.size()-1]=='~'){
        key.pop_back();
    }
    Ins NewNO(archive,key,pos);
    hash[hash_KEY(key)].ins(NewNO);
}

/** \brief
 * Somente um cabe�alho para facilitar o print
 * \param hash_key (int). Index do arquivo a ser exibido
 * \return (void)
 */
 void Hash::print(int hash_Key){
    hash[hash_Key].print();
}

/** \brief
 * Na list pos de cada N_word pode conter mais de uma posi�ao, contudo a
 * pos.front() corresponde � melhor posi�ao para o print; essa fun�ao somente separa a
 * frase em palavras e as busca para a fun��o verify
 * \param phrase (std::string).Frase a ser pesquisada
 * \return (std::vector<std::vector<N_word>>). Vector de vector onde cada index da linha correspode ao index de um arquivo e cada coluna contem uma palavra com a sua melhor posi�ao (pos.front()).
 *
 */
std::vector<Archive> Hash::search(std::string phrase){
    std::stringstream ss(phrase);
    std::string key;
    word ret_Word; /// word definida em Tree.h

    ret_Word.pos.clear();
    ret_Word.word.clear();
    s_words.clear();

    while (ss >> key){
        hash[hash_KEY(key)].sch(key, ret_Word);
        s_words.push_back( ret_Word );
    }
    return verify();
}

/** \brief
 * Na list pos de cada N_word pode conter mais de uma posi�ao, contudo a
 * pos.front() corresponde � melhor posi�ao para o print; essa fun�ao trata os erros que
 * podem vir a acontecer e encaminha o vetor (ja tratado, ou seja, sem erros) para a fun�ao
 * analyze que ir� processar qual � a melhor posi�ao das palavras e qual a melhor ordem delas
 * \return (std::vector<std::vector<N_word>>). Retorna um vector de vector onde cada index da linha correspode ao index de um arquivo e cada coluna contem uma palavra com a sua melhor posi�ao (pos.front())
 */
std::vector<Archive> Hash::verify(){
    std::vector<N_word> Words;
    long arch=0,distance;
    long max_Arch = numText()-1;
    bool success=true;
    std::vector<Archive> archives(max_Arch);


    std::vector<std::vector<N_word> > found_words(max_Arch, std::vector<N_word>());

    /// Verifica se todas as palavras foram encontradas em TODOS os arquivo
    for (std::list<word>::iterator it=s_words.begin();it!=s_words.end();++it){
        if(it->word.empty()){
            archives.clear();
            //std::cout<<"\n\t"<<" ERROR: word not found\n\n";
            return archives;
        }
    }

    while (arch < max_Arch){

        Words = transform(s_words,arch);

        /// Verifica se todas as palavras foram encontradas no arquivo
        for (int i=0;i<Words.size();i++){
            if(Words[i].pos.empty()){
                archives[arch].archive=Data_Text(arch);
                archives[arch].size=0;
                archives[arch].pos.clear();
                //std::cout<<"\n\t"<< Words[i].word <<" not in the file: "<<Data_Text(arch)<<"\n\n";
                success=false;
            }
        }

        if(success){

            archives[arch].archive=Data_Text(arch);
            archives[arch].size=0;
            archives[arch].pos.clear();

            for(int i=0;i<Words.size();i++){
                archives[arch].size+=Words[i].pos.size();
            }

            sort(Words.begin(),Words.end(),sortVec());
            distance = (Words.back().pos.front() - Words.front().pos.front());

            found_words[arch]=analyze(Words,distance,Words);

            for(int i=0;i<Words.size();i++){
                archives[arch].pos.push_back(found_words[arch][i].pos.front());
            }
        }
        Words.clear();
        success=true;
        arch++;
    }

    std::sort(archives.begin(),archives.end(),sortArch());
    return archives;
}


/*****************************
Method: Test()
Param1: (void)
Return: (void)
Obs:  : fun�ao somente para test do codigo
******************************/
void Test(){
    Hash hash;
    std::string archive="test_1.txt";
    std::vector<Archive> found;

    hash.insert(archive,"10",0);
    hash.insert(archive,"3",1);
    hash.insert(archive,"5",2);
    hash.insert(archive,"15",3);
    hash.insert(archive,"19",4);
    hash.insert(archive,"8",5);
    hash.insert(archive,"6",6);
    hash.insert(archive,"9",7);
    hash.insert(archive,"10",8);
    hash.insert(archive,"9",9);
    hash.insert(archive,"15",20);
    hash.insert(archive,"15",21);
    hash.insert(archive,"15",47);

archive="test_2.txt";

    hash.insert(archive,"10!",0);
    hash.insert(archive,"3",1);
    hash.insert(archive,"5",2);
    hash.insert(archive,"19",4);
    hash.insert(archive,"8",5);
    hash.insert(archive,"6",6);
    hash.insert(archive,"9",7);

archive="test_3.txt";

    hash.insert(archive,"15",0);
    hash.insert(archive,"10",1);
    hash.insert(archive,"3",2);
    hash.insert(archive,"5",3);
    hash.insert(archive,"19",4);
    hash.insert(archive,"8",5);
    hash.insert(archive,"6",6);
    hash.insert(archive,"9",7);
    hash.insert(archive,"15",8);
    hash.insert(archive,"15",9);
    hash.insert(archive,"15",10);


    std::cout<<"Preorder traversal of the constructed AVL tree is\n";

    for(int i=0;i<47;i++){
        hash.print(i);
    }

    found = hash.search("10 9 16");

    std::cout<<"INPUT: 10 9 16\n"<<std::endl;

    for(long arch=0;arch<found.size();arch++){
        std::cout<<found[arch].archive<<"\nSize: "<<found[arch].size<<std::endl;
        for(long j=0;j<found[arch].pos.size();j++)
            std::cout<<found[arch].pos[j]<<" ";
        std::cout<<std::endl;
    }

    std::cout<<std::endl;

    found = hash.search("10 9 15");

    std::cout<<"INPUT: 10 9 15\n"<<std::endl;

    for(long arch=0;arch<found.size();arch++){
        std::cout<<found[arch].archive<<"\nSize: "<<found[arch].size<<std::endl;
        for(long j=0;j<found[arch].pos.size();j++)
            std::cout<<found[arch].pos[j]<<" ";
        std::cout<<std::endl<<std::endl;
    }

    std::cout<<std::endl;

    found = hash.search("10 9 6");

    std::cout<<"INPUT: 10 9 6\n"<<std::endl;

    for(long arch=0;arch<found.size();arch++){
        std::cout<<found[arch].archive<<"\nSize: "<<found[arch].size<<std::endl;
        for(long j=0;j<found[arch].pos.size();j++)
            std::cout<<found[arch].pos[j]<<" ";
        std::cout<<std::endl<<std::endl;
    }

    std::cout<<std::endl;
}
